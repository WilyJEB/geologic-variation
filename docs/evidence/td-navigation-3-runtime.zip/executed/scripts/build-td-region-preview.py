"""Add script-free maps to a separate preview; preserve PR58 evidence bytes."""
import html
import json
from pathlib import Path
import re
import zipfile
from xml.etree.ElementTree import Element, SubElement, tostring

ROOT = Path(__file__).resolve().parents[1]
COLORS = ['#8dd0c0', '#efc588', '#b9b4dd', '#d9afa4']


def static_map(d, panel):
    name = ('seed', 'terrain')[panel]
    svg = Element('svg', dict(id=name, viewBox='0 0 590 590', role='img',
                              **{'aria-label': name+' regions and actual retained elevations'}))
    def add(tag, parent=svg, text=None, **attrs):
        e = SubElement(parent, tag, {k.replace('_', '-'): str(v) for k, v in attrs.items()})
        e.text = text
        return e
    x = lambda v: 48+(v-2688)/3073*510
    z = lambda v: 32+(v-10880)/3073*510
    def w(v):
        if not panel or v < 10880 or v > 13952:
            return 0
        q = (v-10880)/64
        r = min(47, int(q))
        return d['rows'][r]['displacement']*(1-q+r)+d['rows'][r+1]['displacement']*(q-r)
    defs = add('defs')
    clip = add('clipPath', defs, id='staticclip'+name)
    add('rect', clip, x=48, y=32, width=510, height=510)
    pattern = add('pattern', defs, id='statichatch'+name, width=15, height=15, patternUnits='userSpaceOnUse')
    add('path', pattern, d='M0 15 L15 0', stroke='#536464', stroke_opacity='.16', stroke_width='.8')
    g = add('g', clip_path='url(#staticclip'+name+')')
    for n, history in enumerate(d['histories']):
        i, j = history['id']
        za = d['phases'][1]+j*2048
        zb = za+2048
        zs = [za]+[row['z'] for row in d['rows'] if za < row['z'] < zb]+[zb]
        left = d['phases'][0]+i*2048
        pts = [(x(left+w(v)), z(v)) for v in zs]+[(x(left+2048+w(v)), z(v)) for v in reversed(zs)]
        add('polygon', g, points=' '.join(f'{a},{b}' for a,b in pts), fill=COLORS[n], fill_opacity='.33')
    add('rect', g, x=48, y=32, width=510, height=510, fill='url(#statichatch'+name+')')
    heights = d['computed_descriptors']['elevations']
    lo, hi = min(map(min, heights)), max(map(max, heights))
    ids = d['terrain_illustration_ids' if panel else 'seed_only_ids']
    for r, row in enumerate(heights):
        for c, value in enumerate(row):
            circle = add('circle', g, cx=x(2688+c*64), cy=z(10880+r*64), r=2.3,
                         fill=f'hsl({225-(value-lo)/(hi-lo)*195} 62% 39%)')
            add('title', circle, text=f'Actual sample r{r} c{c}: x={2688+c*64}, z={10880+r*64}; elevation={value} m; conceptual ID={ids[r][c]}; interpretation abstains; error unknown')
    for i in range(-1, 5):
        left = d['phases'][0]+i*2048
        add('polyline', g, points=' '.join(f"{x(left+w(row['z']))},{z(row['z'])}" for row in d['rows']),
            fill='none', stroke='#283945', stroke_width=2, stroke_dasharray='7 4')
    for j in range(3, 9):
        v = z(d['phases'][1]+j*2048)
        add('line', g, x1=48, x2=558, y1=v, y2=v, stroke='#283945', stroke_width=2, stroke_dasharray='7 4')
    for history in d['histories']:
        i, j = history['id']
        xx, zz = d['phases'][0]+(i+.5)*2048, d['phases'][1]+(j+.5)*2048
        if 2688 < xx < 5761 and 10880 < zz < 13953:
            add('text', g, x=x(xx), y=z(zz), fill='#182c31', font_size=12,
                font_weight=700, paint_order='stroke', stroke='#fffdf7', stroke_width=4,
                text=f"({i},{j}) {history['inherited']} → {history['overprint']}")
    add('rect', x=48, y=32, width=510, height=510, fill='none', stroke='#30434a', stroke_dasharray='2 3')
    for v in (2688,4224,5760):
        add('text', x=x(v), y=564, font_size=11, text_anchor='middle', text=str(v))
    for v in (10880,12416,13952):
        add('text', x=43, y=z(v)+4, font_size=10, text_anchor='end', text=str(v))
    add('text', x=300, y=586, font_size=12, text_anchor='middle', text='native x → / native z ↓')
    return tostring(svg, encoding='unicode')


def build():
    with zipfile.ZipFile(ROOT/'docs/evidence/td-region-visual.zip') as archive:
        d = json.loads(archive.read('result.json'))
        page = archive.read('viewer.html').decode()
    for panel, name in enumerate(('seed', 'terrain')):
        page, count = re.subn(r'<svg id="'+name+r'"[^>]*></svg>', lambda _: static_map(d,panel), page)
        assert count == 1
    rows = [('Visible region IDs','4','4'), ('Sample components per ID','1 each','1 each'),
            ('Adjacent-ID transitions','98','116'), ('Changed labelled sites','—','149 / 2401'),
            ('Geological interpretation','Abstain everywhere','Abstain everywhere')]
    table = ''.join('<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in row)+'</tr>' for row in rows)
    page = page.replace('<tbody id="checks"></tbody>', '<tbody id="checks">'+table+'</tbody>')
    h = d['computed_descriptors']['elevations']
    page = page.replace('<div id="scale"></div>', f'<div id="scale"><b>Observed point scale:</b> blue {min(map(min,h)):.1f} → green → orange {max(map(max,h)):.1f} metres.</div>')
    page = page.replace('<select id="layer">', '<select id="layer" disabled>')
    page = page.replace('type="checkbox" checked', 'type="checkbox" checked disabled')
    page = page.replace("join('');draw();", "join('');draw();document.querySelectorAll('select,input').forEach(e=>e.disabled=false);")
    page = page.replace('Select any sample to inspect its observation and both conceptual identities.',
                        'Maps are embedded and remain visible without scripts. Hover a point for its observation. Interactive controls require a browser that permits scripts.')
    output = ROOT/'docs/td-region-viewer.html'
    output.write_bytes(page.encode())
    return output


if __name__ == '__main__':
    print(build())
